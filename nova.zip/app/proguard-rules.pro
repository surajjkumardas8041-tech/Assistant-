# Proguard rules for Nova AI Assistant
-keepattributes *Annotation*
