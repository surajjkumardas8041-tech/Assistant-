package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import com.example.ui.NovaHomeScreen
import com.example.ui.NovaViewModel
import com.example.ui.theme.NovaTheme
import com.example.util.PermissionManager

class MainActivity : ComponentActivity() {
    private val viewModel: NovaViewModel by viewModels()
    private var hasRequiredPermissions by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasRequiredPermissions = permissions.values.all { it }
        if (hasRequiredPermissions) {
            viewModel.startService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        hasRequiredPermissions = PermissionManager.hasAllRequiredPermissions(this)
        if (hasRequiredPermissions) {
            viewModel.startService()
        }

        setContent {
            NovaTheme {
                NovaHomeScreen(
                    viewModel = viewModel,
                    hasPermissions = hasRequiredPermissions,
                    onRequestPermissions = {
                        permissionLauncher.launch(PermissionManager.REQUIRED_PERMISSIONS)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasRequiredPermissions = PermissionManager.hasAllRequiredPermissions(this)
    }
}
