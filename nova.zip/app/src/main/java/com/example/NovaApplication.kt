package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log

class NovaApplication : Application() {
    companion object {
        const val CHANNEL_ID = "nova_service_channel"
        const val CHANNEL_NAME = "Nova Assistant Service"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        Log.i("NovaApplication", "NovaApplication initialized")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Nova Live AI Assistant listening in the background"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
