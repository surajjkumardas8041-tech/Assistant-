package com.example.core.action

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.ContactsContract
import android.util.Log
import com.example.data.prefs.NovaPreferences
import java.text.SimpleDateFormat
import java.util.*

data class VoiceCommandResult(
    val query: String,
    val responseText: String,
    val actionExecuted: String,
    val success: Boolean
)

class IntentActionHandler(
    private val context: Context,
    private val preferences: NovaPreferences,
    var onCallInitiatedWithSpeaker: ((target: String) -> Unit)? = null
) {
    private val tag = "IntentActionHandler"
    private var isTorchOn = false

    fun processCommand(rawQuery: String): VoiceCommandResult? {
        val query = rawQuery.trim()
        val lower = query.lowercase(Locale.getDefault())
        val owner = preferences.ownerName

        // 1. YouTube
        if (matchesAny(lower, "youtube", "ইউটিউব", "ইউটিউব খোলো", "open youtube", "play youtube")) {
            val success = launchAppOrUrl("com.google.android.youtube", "https://www.youtube.com")
            val resp = if (success) "জি $owner, YouTube খুলছি।" else "YouTube খুলতে পারছি না।"
            return VoiceCommandResult(query, resp, "OPEN_YOUTUBE", success)
        }

        // 2. WhatsApp
        if (matchesAny(lower, "whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ খোলো", "open whatsapp")) {
            val success = launchAppOrUrl("com.whatsapp", null)
            val resp = if (success) "জি $owner, WhatsApp চালু করছি।" else "WhatsApp খুঁজে পাওয়া যায়নি।"
            return VoiceCommandResult(query, resp, "OPEN_WHATSAPP", success)
        }

        // 3. Google Maps
        if (matchesAny(lower, "maps", "ম্যাপ", "ম্যাপস", "গুগল ম্যাপ", "open maps", "directions")) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val success = safeStartActivity(intent)
            val resp = if (success) "জি $owner, Google Maps খুলছি।" else "Maps খুলতে ব্যর্থ হয়েছে।"
            return VoiceCommandResult(query, resp, "OPEN_MAPS", success)
        }

        // 4. Camera
        if (matchesAny(lower, "camera", "ক্যামেরা", "ক্যামেরা খোলো", "open camera", "take photo", "ছবি তোলো")) {
            val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val success = safeStartActivity(intent)
            val resp = if (success) "জি $owner, ক্যামেরা চালু করছি।" else "ক্যামেরা চালু করা যায়নি।"
            return VoiceCommandResult(query, resp, "OPEN_CAMERA", success)
        }

        // 5. Flashlight / Torch
        if (matchesAny(lower, "flashlight", "torch", "ফ্ল্যাশলাইট", "টর্চ", "লাইট জ্বালাও", "লাইট বন্ধ")) {
            val turnOn = !lower.contains("বন্ধ") && !lower.contains("off") && !lower.contains("stop")
            val success = toggleFlashlight(turnOn)
            val resp = if (success) {
                if (turnOn) "জি $owner, ফ্ল্যাশলাইট জ্বালিয়েছি।" else "জি $owner, ফ্ল্যাশলাইট বন্ধ করেছি।"
            } else {
                "ফ্ল্যাশলাইট নিয়ন্ত্রণ করা যায়নি।"
            }
            return VoiceCommandResult(query, resp, "TOGGLE_FLASHLIGHT", success)
        }

        // 6. Time Query
        if (matchesAny(lower, "time", "সময়", "কটা বাজে", "time please", "what time is it", "এখন কয়টা বাজে")) {
            val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val resp = "জি $owner, এখন সময় $timeStr"
            return VoiceCommandResult(query, resp, "GET_TIME", true)
        }

        // 7. Date Query
        if (matchesAny(lower, "date", "তারিখ", "আজ কি বার", "আজ কত তারিখ", "what is the date", "today's date")) {
            val dateStr = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            val resp = "জি $owner, আজ $dateStr"
            return VoiceCommandResult(query, resp, "GET_DATE", true)
        }

        // 8. Battery Status
        if (matchesAny(lower, "battery", "ব্যাটারি", "চার্জ কত", "battery level", "battery status", "চার্জ কেমন আছে")) {
            val (level, isCharging) = getBatteryInfo()
            val chargingText = if (isCharging) "এবং ফোনটি চার্জ হচ্ছে।" else "।"
            val resp = "জি $owner, ব্যাটারি চার্জ আছে $level%$chargingText"
            return VoiceCommandResult(query, resp, "GET_BATTERY", true)
        }

        // 9. Readiness check
        if (matchesAny(lower, "রেডি আছো", "তুমি তৈরি", "are you ready", "are you prepared", "রেডি?", "রেডি", "প্রস্তুত", "তুমি প্রস্তুত", "তুমি কি প্রস্তুত")) {
            val resp = "জি $owner, আমি সর্বদা প্রস্তুত আছি। আপনি আদেশ দিন।"
            return VoiceCommandResult(query, resp, "CHECK_READY", true)
        }

        // 10. Phone Call
        val targetContact = extractCallTarget(lower)
        if (targetContact != null) {
            val (resp, success) = makePhoneCall(targetContact)
            return VoiceCommandResult(query, resp, "CALL_PHONE", success)
        }

        return null
    }

    private fun matchesAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it) }
    }

    fun extractCallTarget(rawLower: String): String? {
        val lower = rawLower
            .replace("।", " ")
            .replace("?", " ")
            .replace("!", " ")
            .replace(",", " ")
            .replace(".", " ")
            .trim()

        val stripped = lower
            .replace("hey nova", "")
            .replace("nova", "")
            .replace("নোভা", "")
            .replace("প্লিজ", "")
            .replace("please", "")
            .replace("দয়া করে", "")
            .replace("দয়া করে", "")
            .trim()

        // Suffix Bengali keywords
        val bengaliKeywords = listOf(
            "ফোন করো", "কল করো", "ফোন দাও", "কল দাও",
            "ফোন লাগাও", "কল লাগাও", "ফোন কর", "কল কর",
            "ডায়াল করো", "ডায়াল করো"
        )
        for (kw in bengaliKeywords) {
            val idx = stripped.indexOf(kw)
            if (idx != -1) {
                val prefix = stripped.substring(0, idx).trim()
                if (prefix.isNotEmpty()) {
                    val cleanTarget = cleanTargetName(prefix)
                    if (cleanTarget.isNotEmpty()) return cleanTarget
                }
                val suffix = stripped.substring(idx + kw.length).trim()
                if (suffix.isNotEmpty()) {
                    val cleanTarget = cleanTargetName(suffix)
                    if (cleanTarget.isNotEmpty()) return cleanTarget
                }
            }
        }

        // Prefix keywords
        val prefixKeywords = listOf(
            "call ", "phone ", "dial ", "make a call to ",
            "কল করো ", "ফোন করো ", "কল দাও ", "ফোন দাও "
        )
        for (kw in prefixKeywords) {
            if (stripped.startsWith(kw)) {
                val rem = stripped.removePrefix(kw).trim()
                val cleanTarget = cleanTargetName(rem)
                if (cleanTarget.isNotEmpty()) return cleanTarget
            }
        }

        return null
    }

    private fun cleanTargetName(raw: String): String {
        var t = raw.trim()
        if (t.endsWith("এর কাছে")) t = t.removeSuffix("এর কাছে").trim()
        else if (t.endsWith("কাছে")) t = t.removeSuffix("কাছে").trim()

        if (t.endsWith("-এ")) t = t.removeSuffix("-এ").trim()
        else if (t.endsWith(" এ") && t.length > 2) t = t.removeSuffix(" এ").trim()

        if (t.endsWith("-কে")) t = t.removeSuffix("-কে").trim()
        else if (t.endsWith("কে") && t.length > 2) t = t.removeSuffix("কে").trim()

        if (t.endsWith("-তে")) t = t.removeSuffix("-তে").trim()
        else if (t.endsWith("তে") && t.length > 2) t = t.removeSuffix("তে").trim()

        return t.trim()
    }

    private fun makePhoneCall(target: String): Pair<String, Boolean> {
        val owner = preferences.ownerName
        val isNumeric = target.matches(Regex("[0-9+\\- ]+"))
        val phoneNumber = if (isNumeric) target.replace(" ", "") else lookupContactNumber(target)

        return if (phoneNumber != null) {
            try {
                onCallInitiatedWithSpeaker?.invoke(target)
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
                Pair("জি $owner, $target-কে কল দেওয়া হচ্ছে।", true)
            } catch (e: SecurityException) {
                onCallInitiatedWithSpeaker?.invoke(target)
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                safeStartActivity(dialIntent)
                Pair("জি $owner, $target-এর জন্য ডায়ালার প্রস্তুত করেছি।", true)
            } catch (e: Exception) {
                Log.e(tag, "Failed to place call", e)
                Pair("কল করতে সমস্যা হয়েছে।", false)
            }
        } else {
            try {
                onCallInitiatedWithSpeaker?.invoke(target)
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$target")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
                Pair("জি $owner, $target এর জন্য কল প্রস্তুত করা হয়েছে।", true)
            } catch (e: Exception) {
                Log.e(tag, "Dialer launch failed", e)
                Pair("$target এর নাম্বার খুঁজে পাওয়া যায়নি।", false)
            }
        }
    }

    private fun lookupContactNumber(name: String): String? {
        return try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (numIdx != -1) it.getString(numIdx) else null
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun launchAppOrUrl(packageName: String, fallbackUrl: String?): Boolean {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                true
            } else if (fallbackUrl != null) {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                safeStartActivity(browserIntent)
            } else false
        } catch (e: Exception) {
            Log.e(tag, "Error launching app: $packageName", e)
            false
        }
    }

    private fun toggleFlashlight(turnOn: Boolean): Boolean {
        return try {
            val camManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = camManager?.cameraIdList?.firstOrNull() ?: return false
            camManager.setTorchMode(cameraId, turnOn)
            isTorchOn = turnOn
            true
        } catch (e: Exception) {
            Log.w(tag, "Flashlight toggle failed: ${e.message}")
            false
        }
    }

    private fun getBatteryInfo(): Pair<Int, Boolean> {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 85
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return Pair(pct, isCharging)
    }

    private fun safeStartActivity(intent: Intent): Boolean {
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(tag, "safeStartActivity error: ${e.message}")
            false
        }
    }
}
