package com.example.core.ai

import android.content.Context
import android.util.Log
import com.example.data.prefs.NovaPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class NovaAIManager(
    private val context: Context,
    private val preferences: NovaPreferences
) {
    private val tag = "NovaAIManager"

    suspend fun generateResponse(userQuery: String): String = withContext(Dispatchers.IO) {
        val owner = preferences.ownerName
        val lower = userQuery.lowercase(Locale.getDefault())

        // Quick intelligent conversational patterns
        if (lower.contains("কেমন আছো") || lower.contains("how are you")) {
            return@withContext "জি $owner, আমি সম্পূর্ণ প্রস্তুত ও সক্রিয় আছি। আপনি কেমন আছেন?"
        }

        if (lower.contains("তুমি কে") || lower.contains("who are you") || lower.contains("তোমার পরিচয়")) {
            return@withContext "আমি নোভা, আপনার ব্যক্তিগত সার্বক্ষণিক লাইভ এআই অ্যাসিস্ট্যান্ট। আমি আপনার সেবায় নিয়োজিত।"
        }

        if (lower.contains("ধন্যবাদ") || lower.contains("thank you") || lower.contains("thanks")) {
            return@withContext "স্বাগতম $owner! আপনাকে সাহায্য করতে পেরে আমি আনন্দিত।"
        }

        if (lower.contains("তোমার নাম কি") || lower.contains("what is your name")) {
            return@withContext "আমার নাম নোভা। আমি আপনার হ্যান্ডস-ফ্রি এআই সহকারী।"
        }

        if (lower.contains("সাহায্য") || lower.contains("help") || lower.contains("কি করতে পারো")) {
            return@withContext "জি $owner, আমি কল করা, YouTube খোলা, WhatsApp চালু করা, ক্যামেরা, ম্যাপস, টর্চ লাইট, ব্যাটারি ও সময় বলাসহ যেকোনো বিষয়ে আপনাকে সাহায্য করতে পারি।"
        }

        // Generic friendly response preserving owner address
        val isBengali = userQuery.any { it.code in 0x0980..0x09FF }
        if (isBengali) {
            "জি $owner, আমি আপনার নির্দেশ বুঝতে পেরেছি। বলুন কিভাবে সাহায্য করবো?"
        } else {
            "Yes $owner, I heard: \"$userQuery\". How can I assist you further?"
        }
    }
}
