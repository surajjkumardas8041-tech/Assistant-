package com.example.core.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * CallStateManager handles telephony lifecycle transitions, audio focus management,
 * and automatic loudspeaker routing for hands-free voice operations.
 */
class CallStateManager(
    private val context: Context,
    private val onCallStarted: () -> Unit,
    private val onCallEnded: () -> Unit,
    private val onAudioFocusLost: (isTransient: Boolean) -> Unit,
    private val onAudioFocusGained: () -> Unit,
    private val onMicrophoneSilenced: () -> Unit = {},
    private val onMicrophoneAvailable: () -> Unit = {},
    private val onSpeakerphoneActivated: ((target: String) -> Unit)? = null
) {
    private val tag = "CallStateManager"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    val speakerphoneController = SpeakerphoneController(context)

    private val isCallActive = AtomicBoolean(false)
    private val isRinging = AtomicBoolean(false)
    private val isAutoSpeakerPending = AtomicBoolean(false)
    private var pendingTarget: String? = null
    private var lastCallState = TelephonyManager.CALL_STATE_IDLE

    private var telephonyCallback: Any? = null
    private var phoneStateListener: PhoneStateListener? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.w(tag, "Permanent AudioFocus LOSS")
                onAudioFocusLost(false)
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                Log.i(tag, "Transient AudioFocus LOSS (ducking)")
                onAudioFocusLost(true)
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.i(tag, "AudioFocus GAINED")
                onAudioFocusGained()
            }
        }
    }

    fun requestNovaAudioFocus(): Boolean {
        val am = audioManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(audioFocusChangeListener, mainHandler)
                .build()

            audioFocusRequest = req
            val res = am.requestAudioFocus(req)
            res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            val res = am.requestAudioFocus(
                audioFocusChangeListener,
                AudioManager.STREAM_VOICE_CALL,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
            res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    fun releaseNovaAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusChangeListener)
        }
    }

    fun startListening() {
        val tm = telephonyManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handleCallStateTransition(state)
                    }
                }
                telephonyCallback = callback
                context.mainExecutor.let { tm.registerTelephonyCallback(it, callback) }
                Log.i(tag, "TelephonyCallback registered (Android 12+)")
            } else {
                @Suppress("DEPRECATION")
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        handleCallStateTransition(state)
                    }
                }
                phoneStateListener = listener
                @Suppress("DEPRECATION")
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
                Log.i(tag, "PhoneStateListener registered (Pre-Android 12)")
            }
        } catch (e: SecurityException) {
            Log.w(tag, "READ_PHONE_STATE permission missing: ${e.message}")
        } catch (e: Exception) {
            Log.e(tag, "Failed to register call state listener: ${e.message}")
        }
    }

    fun stopListening() {
        val tm = telephonyManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (telephonyCallback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                phoneStateListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (e: Exception) {
            Log.w(tag, "Error unregistering telephony listener: ${e.message}")
        }
    }

    fun prepareOutgoingCallSpeaker(target: String) {
        Log.i(tag, "Preparing automatic call loudspeaker for target: $target")
        isAutoSpeakerPending.set(true)
        pendingTarget = target
    }

    fun handleCallStateTransition(state: Int) {
        mainHandler.post {
            val previousState = lastCallState
            lastCallState = state
            val wasInCallOrRinging = isCallActive.get() || isRinging.get()

            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> {
                    isRinging.set(true)
                    Log.i(tag, "PHONE CALL RINGING: Pausing Nova mic & speech")
                    onCallStarted()
                }
                TelephonyManager.CALL_STATE_OFFHOOK -> {
                    isRinging.set(false)
                    isCallActive.set(true)
                    Log.i(tag, "PHONE CALL ACTIVE (OFFHOOK): Nova microphone paused")
                    onCallStarted()

                    if (isAutoSpeakerPending.compareAndSet(true, false)) {
                        val target = pendingTarget ?: "Contact"
                        Log.i(tag, "Call connected to $target: Turning ON speakerphone")
                        val enabled = speakerphoneController.enableSpeakerphone()
                        if (enabled) {
                            onSpeakerphoneActivated?.invoke(target)
                        }
                    }
                }
                TelephonyManager.CALL_STATE_IDLE -> {
                    isRinging.set(false)
                    isCallActive.set(false)
                    isAutoSpeakerPending.set(false)
                    pendingTarget = null

                    speakerphoneController.disableSpeakerphone()

                    if (wasInCallOrRinging) {
                        Log.i(tag, "PHONE CALL ENDED / IDLE: Recovering to READY")
                        mainHandler.postDelayed({
                            requestNovaAudioFocus()
                            onCallEnded()
                        }, 400)
                    }
                }
            }
        }
    }

    fun isPhoneCallOngoing(): Boolean {
        return isCallActive.get() || isRinging.get()
    }
}
