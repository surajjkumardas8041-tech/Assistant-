package com.example.core.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.sin

/**
 * Procedural low-latency sound cues for hands-free state transitions.
 * Eliminates reliance on external audio asset files.
 */
object SoundEffects {
    private const val SAMPLE_RATE = 44100

    fun playWakeBeep() {
        playTone(frequency = 880.0, durationMs = 80, volume = 0.4f)
    }

    fun playAcknowledgeTone() {
        playDualTone(freq1 = 587.33, freq2 = 880.0, durationMs = 120, volume = 0.35f)
    }

    fun playSuccessTone() {
        playDualTone(freq1 = 523.25, freq2 = 1046.50, durationMs = 140, volume = 0.35f)
    }

    fun playSecurityRejectTone() {
        playTone(frequency = 220.0, durationMs = 180, volume = 0.4f)
    }

    private fun playTone(frequency: Double, durationMs: Int, volume: Float) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val angle = 2.0 * Math.PI * i / (SAMPLE_RATE / frequency)
                    val envelope = 1.0 - (i.toDouble() / numSamples) // Linear fade out
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * volume * envelope).toInt().toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 50)
                track.stop()
                track.release()
            } catch (_: Exception) {}
        }.start()
    }

    private fun playDualTone(freq1: Double, freq2: Double, durationMs: Int, volume: Float) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                val half = numSamples / 2
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val freq = if (i < half) freq1 else freq2
                    val angle = 2.0 * Math.PI * i / (SAMPLE_RATE / freq)
                    val envelope = 1.0 - (i.toDouble() / numSamples)
                    buffer[i] = (sin(angle) * Short.MAX_VALUE * volume * envelope).toInt().toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 50)
                track.stop()
                track.release()
            } catch (_: Exception) {}
        }.start()
    }
}
