package com.example.core.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log

/**
 * SpeakerphoneController:
 * Uses official Android APIs to automatically route telephone audio to the loudspeaker.
 * - On Android 12+ (API 31+): Uses AudioManager.setCommunicationDevice with TYPE_BUILTIN_SPEAKER.
 * - On pre-API 31: Uses AudioManager.isSpeakerphoneOn and AudioManager.MODE_IN_CALL.
 * - Gracefully handles failures without unsafe or private APIs.
 */
class SpeakerphoneController(private val context: Context) {
    private val tag = "SpeakerphoneCtrl"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    /**
     * Attempts to turn on the loudspeaker using officially supported Android telephony/audio APIs.
     * Returns true if speakerphone was enabled, false if unable/restricted.
     */
    fun enableSpeakerphone(): Boolean {
        val am = audioManager ?: run {
            Log.w(tag, "AudioManager unavailable, cannot toggle speakerphone")
            return false
        }

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val availableDevices = am.availableCommunicationDevices
                val speakerDevice = availableDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                }

                if (speakerDevice != null) {
                    val result = am.setCommunicationDevice(speakerDevice)
                    Log.i(tag, "setCommunicationDevice(TYPE_BUILTIN_SPEAKER) returned $result")
                    if (result) {
                        try {
                            am.isSpeakerphoneOn = true
                        } catch (e: Exception) {
                            Log.d(tag, "Secondary isSpeakerphoneOn flag skipped: ${e.message}")
                        }
                        return true
                    }
                }
                // Fallback for API 31+ if setCommunicationDevice returned false
                am.mode = AudioManager.MODE_IN_CALL
                am.isSpeakerphoneOn = true
                Log.i(tag, "API 31+ speakerphone fallback enabled (isSpeakerphoneOn=true)")
                true
            } else {
                // Pre-API 31 official flow
                am.mode = AudioManager.MODE_IN_CALL
                am.isSpeakerphoneOn = true
                Log.i(tag, "Pre-API 31 speakerphone enabled (mode=MODE_IN_CALL, isSpeakerphoneOn=true)")
                true
            }
        } catch (e: SecurityException) {
            Log.w(tag, "SecurityException while enabling speakerphone: ${e.message}")
            false
        } catch (e: Exception) {
            Log.e(tag, "Failed to enable speakerphone: ${e.message}", e)
            false
        }
    }

    /**
     * Resets audio routing back to standard earpiece/normal mode and releases communication devices.
     */
    fun disableSpeakerphone() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                am.clearCommunicationDevice()
            }
            am.isSpeakerphoneOn = false
            am.mode = AudioManager.MODE_NORMAL
            Log.i(tag, "Speakerphone disabled and audio mode reset to MODE_NORMAL")
        } catch (e: Exception) {
            Log.w(tag, "Error resetting speakerphone: ${e.message}")
        }
    }

    fun isSpeakerphoneOn(): Boolean {
        return audioManager?.isSpeakerphoneOn == true
    }
}
