package com.example.core.audio

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * TextToSpeechManager:
 * Provides bilingual TTS responses in Bengali ("bn-BD"/"bn-IN") and English ("en-US").
 */
class TextToSpeechManager(
    private val context: Context,
    private val onInitSuccess: () -> Unit = {},
    private val onSpeechDone: () -> Unit = {}
) {
    private val tag = "TextToSpeechManager"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                configureTTS()
                onInitSuccess()
                Log.i(tag, "TTS initialized successfully")
            } else {
                Log.e(tag, "TTS initialization failed with code: $status")
            }
        }
    }

    private fun configureTTS() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                Log.d(tag, "TTS onStart: $utteranceId")
            }

            override fun onDone(utteranceId: String?) {
                Log.d(tag, "TTS onDone: $utteranceId")
                mainHandler.post { onSpeechDone() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                Log.w(tag, "TTS onError: $utteranceId")
                mainHandler.post { onSpeechDone() }
            }
        })
    }

    fun speak(text: String, pitch: Float = 1.0f, speed: Float = 1.05f) {
        if (!isInitialized || text.isBlank()) {
            onSpeechDone()
            return
        }

        try {
            tts?.setPitch(pitch)
            tts?.setSpeechRate(speed)

            val isBengali = isBengaliText(text)
            if (isBengali) {
                val bnLocale = Locale.forLanguageTag("bn-BD")
                val res = tts?.setLanguage(bnLocale)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.forLanguageTag("bn-IN"))
                }
            } else {
                tts?.setLanguage(Locale.US)
            }

            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "nova_tts_${System.currentTimeMillis()}")
            }

            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "nova_tts_id")
            Log.i(tag, "TTS speaking: $text")
        } catch (e: Exception) {
            Log.e(tag, "Error in TTS speak: ${e.message}", e)
            onSpeechDone()
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.w(tag, "Error stopping TTS: ${e.message}")
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isInitialized = false
        } catch (e: Exception) {
            Log.w(tag, "Error shutting down TTS: ${e.message}")
        }
    }

    private fun isBengaliText(text: String): Boolean {
        for (char in text) {
            val code = char.code
            if (code in 0x0980..0x09FF) {
                return true
            }
        }
        return false
    }
}
