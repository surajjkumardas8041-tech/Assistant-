package com.example.core.audio

import android.util.Log
import kotlin.math.*

/**
 * On-device Voice Biometrics Engine:
 * Extracts acoustic feature vectors (MFCC approximations, F0 fundamental frequency,
 * spectral centroid, and zero-crossing rate) from PCM audio buffers.
 * Compares voice signatures using cosine similarity + Euclidean distance.
 */
class VoiceBiometricsEngine {
    private val tag = "VoiceBiometrics"
    private val sampleRate = 16000
    private val frameSize = 512
    private val numFilters = 16

    data class VoiceFeatures(
        val mfcc: FloatArray,
        val fundamentalFreq: Float,
        val spectralCentroid: Float,
        val energy: Float,
        val zeroCrossingRate: Float
    ) {
        fun toSerializedString(): String {
            val mfccStr = mfcc.joinToString(",") { "%.4f".format(it) }
            return "$mfccStr|$fundamentalFreq|$spectralCentroid|$energy|$zeroCrossingRate"
        }

        companion object {
            fun fromSerializedString(str: String): VoiceFeatures? {
                return try {
                    val parts = str.split("|")
                    if (parts.size < 5) return null
                    val mfcc = parts[0].split(",").map { it.toFloat() }.toFloatArray()
                    val f0 = parts[1].toFloat()
                    val sc = parts[2].toFloat()
                    val energy = parts[3].toFloat()
                    val zcr = parts[4].toFloat()
                    VoiceFeatures(mfcc, f0, sc, energy, zcr)
                } catch (e: Exception) {
                    null
                }
            }
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is VoiceFeatures) return false
            return mfcc.contentEquals(other.mfcc) &&
                    fundamentalFreq == other.fundamentalFreq &&
                    spectralCentroid == other.spectralCentroid
        }

        override fun hashCode(): Int {
            return mfcc.contentHashCode()
        }
    }

    fun extractFeatures(pcmBuffer: ShortArray): VoiceFeatures {
        if (pcmBuffer.isEmpty()) {
            return VoiceFeatures(FloatArray(numFilters), 0f, 0f, 0f, 0f)
        }

        // Energy
        var sumSquares = 0.0
        var zeroCrossings = 0
        for (i in pcmBuffer.indices) {
            val sample = pcmBuffer[i].toDouble()
            sumSquares += sample * sample
            if (i > 0 && ((pcmBuffer[i] >= 0 && pcmBuffer[i - 1] < 0) || (pcmBuffer[i] < 0 && pcmBuffer[i - 1] >= 0))) {
                zeroCrossings++
            }
        }
        val rmsEnergy = sqrt(sumSquares / pcmBuffer.size).toFloat()
        val zcr = zeroCrossings.toFloat() / pcmBuffer.size

        // Autocorrelation Pitch (F0) Estimation
        val f0 = estimatePitchF0(pcmBuffer, sampleRate)

        // Spectral features
        val mfccVector = computeFilterBankEnergies(pcmBuffer, numFilters)
        val spectralCentroid = computeSpectralCentroid(pcmBuffer)

        return VoiceFeatures(
            mfcc = mfccVector,
            fundamentalFreq = f0,
            spectralCentroid = spectralCentroid,
            energy = rmsEnergy,
            zeroCrossingRate = zcr
        )
    }

    private fun estimatePitchF0(buffer: ShortArray, sampleRate: Int): Float {
        val minLag = sampleRate / 350 // Max pitch ~350Hz
        val maxLag = sampleRate / 75  // Min pitch ~75Hz
        var maxCorr = 0.0
        var bestLag = 0

        val n = min(buffer.size, 1024)
        for (lag in minLag..min(maxLag, n - 1)) {
            var corr = 0.0
            for (i in 0 until (n - lag)) {
                corr += buffer[i].toDouble() * buffer[i + lag].toDouble()
            }
            if (corr > maxCorr) {
                maxCorr = corr
                bestLag = lag
            }
        }
        return if (bestLag > 0) sampleRate.toFloat() / bestLag else 140f
    }

    private fun computeFilterBankEnergies(buffer: ShortArray, numBands: Int): FloatArray {
        val energies = FloatArray(numBands)
        if (buffer.isEmpty()) return energies

        // Compute power spectrum via DFT across audio frequencies (0 Hz to 4000 Hz)
        val maxFreq = 4000.0
        val freqStep = maxFreq / numBands
        val n = min(buffer.size, 512)

        for (b in 0 until numBands) {
            val centerFreq = (b + 0.5) * freqStep
            val omega = 2.0 * Math.PI * centerFreq / sampleRate
            var realSum = 0.0
            var imagSum = 0.0
            for (i in 0 until n) {
                val s = buffer[i].toDouble()
                realSum += s * cos(omega * i)
                imagSum -= s * sin(omega * i)
            }
            val power = (realSum * realSum + imagSum * imagSum) / n
            energies[b] = ln(max(1.0, power)).toFloat()
        }

        // Normalize energy vector
        var norm = 0.0
        for (v in energies) norm += v * v
        norm = sqrt(norm)
        if (norm > 0) {
            for (i in energies.indices) energies[i] = (energies[i] / norm).toFloat()
        }
        return energies
    }

    private fun computeSpectralCentroid(buffer: ShortArray): Float {
        var weightedSum = 0.0
        var totalMag = 0.0
        for (i in buffer.indices) {
            val mag = abs(buffer[i].toDouble())
            weightedSum += i * mag
            totalMag += mag
        }
        return if (totalMag > 0) (weightedSum / totalMag).toFloat() else 0f
    }

    /**
     * Calculates similarity score (0.0 to 1.0) between enrolled template and live audio features.
     */
    fun computeSimilarity(enrolled: VoiceFeatures, live: VoiceFeatures): Float {
        // Cosine similarity of filter bank energies
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in enrolled.mfcc.indices) {
            val a = enrolled.mfcc.getOrElse(i) { 0f }.toDouble()
            val b = live.mfcc.getOrElse(i) { 0f }.toDouble()
            dot += a * b
            normA += a * a
            normB += b * b
        }
        val cosineSim = if (normA > 0 && normB > 0) {
            (dot / (sqrt(normA) * sqrt(normB))).toFloat().coerceIn(0f, 1f)
        } else 0f

        // Pitch difference penalty (fundamental frequency mismatch)
        val f0Diff = abs(enrolled.fundamentalFreq - live.fundamentalFreq)
        val pitchScore = (1.0f - (f0Diff / 75f)).coerceIn(0f, 1f)

        // Spectral centroid match
        val scDiff = abs(enrolled.spectralCentroid - live.spectralCentroid)
        val scScore = (1.0f - (scDiff / 400f)).coerceIn(0f, 1f)

        // Weighted composite score
        val composite = (cosineSim * 0.50f) + (pitchScore * 0.35f) + (scScore * 0.15f)
        return composite.coerceIn(0f, 1f)
    }
}
