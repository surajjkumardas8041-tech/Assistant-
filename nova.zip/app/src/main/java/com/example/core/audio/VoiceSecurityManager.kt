package com.example.core.audio

import android.content.Context
import android.util.Log
import com.example.data.prefs.NovaPreferences

/**
 * VoiceSecurityManager:
 * Enforces personal voice security for the owner (তাপস স্যার).
 * Matches acoustic signatures, handles multi-sample enrollment, and rejects unauthorized speakers.
 */
class VoiceSecurityManager(
    private val context: Context,
    private val preferences: NovaPreferences
) {
    private val tag = "VoiceSecurityManager"
    private val biometricsEngine = VoiceBiometricsEngine()

    data class VerificationResult(
        val isVerified: Boolean,
        val confidence: Float,
        val reason: String
    )

    fun isSecurityEnabled(): Boolean = preferences.isVoiceSecurityEnabled

    fun isOwnerEnrolled(): Boolean = preferences.isOwnerEnrolled()

    /**
     * Enrolls or adds a sample to the owner voice profile.
     */
    fun enrollSample(pcmData: ShortArray): Boolean {
        return try {
            val features = biometricsEngine.extractFeatures(pcmData)
            val currentTemplateStr = preferences.ownerVoiceTemplate
            if (currentTemplateStr.isNullOrEmpty()) {
                preferences.ownerVoiceTemplate = features.toSerializedString()
                preferences.enrollmentSampleCount = 1
            } else {
                val existing = VoiceBiometricsEngine.VoiceFeatures.fromSerializedString(currentTemplateStr)
                if (existing != null) {
                    // Average MFCC vectors
                    val mergedMfcc = FloatArray(existing.mfcc.size) { idx ->
                        (existing.mfcc[idx] + features.mfcc[idx]) / 2.0f
                    }
                    val mergedF0 = (existing.fundamentalFreq + features.fundamentalFreq) / 2.0f
                    val mergedSc = (existing.spectralCentroid + features.spectralCentroid) / 2.0f
                    val merged = VoiceBiometricsEngine.VoiceFeatures(
                        mfcc = mergedMfcc,
                        fundamentalFreq = mergedF0,
                        spectralCentroid = mergedSc,
                        energy = (existing.energy + features.energy) / 2.0f,
                        zeroCrossingRate = (existing.zeroCrossingRate + features.zeroCrossingRate) / 2.0f
                    )
                    preferences.ownerVoiceTemplate = merged.toSerializedString()
                    preferences.enrollmentSampleCount += 1
                }
            }
            Log.i(tag, "Voice sample enrolled. Total samples: ${preferences.enrollmentSampleCount}")
            true
        } catch (e: Exception) {
            Log.e(tag, "Failed to enroll voice sample: ${e.message}", e)
            false
        }
    }

    /**
     * Verifies live spoken PCM audio against owner voice template.
     */
    fun verifyVoice(pcmData: ShortArray): VerificationResult {
        if (!preferences.isVoiceSecurityEnabled) {
            return VerificationResult(isVerified = true, confidence = 1.0f, reason = "Security disabled by user")
        }

        val templateStr = preferences.ownerVoiceTemplate
        if (templateStr.isNullOrEmpty()) {
            // First time setup: auto-enroll first detected voice sample for seamless out-of-the-box experience
            enrollSample(pcmData)
            return VerificationResult(isVerified = true, confidence = 0.95f, reason = "Initial voice sample enrolled as owner")
        }

        val enrolled = VoiceBiometricsEngine.VoiceFeatures.fromSerializedString(templateStr)
            ?: return VerificationResult(isVerified = false, confidence = 0f, reason = "Corrupt voice template")

        val liveFeatures = biometricsEngine.extractFeatures(pcmData)
        val similarity = biometricsEngine.computeSimilarity(enrolled, liveFeatures)
        val threshold = preferences.voiceSensitivity

        val isMatch = similarity >= threshold
        val reason = if (isMatch) {
            "Voice verified for owner: ${preferences.ownerName} (Score: ${(similarity * 100).toInt()}%)"
        } else {
            "Unauthorized speaker rejected (Score: ${(similarity * 100).toInt()}% < ${(threshold * 100).toInt()}%)"
        }

        Log.i(tag, reason)
        return VerificationResult(isVerified = isMatch, confidence = similarity, reason = reason)
    }

    fun resetEnrollment() {
        preferences.ownerVoiceTemplate = null
        preferences.enrollmentSampleCount = 0
        Log.i(tag, "Owner voice profile cleared")
    }
}
