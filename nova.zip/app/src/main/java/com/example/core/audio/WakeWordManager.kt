package com.example.core.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * WakeWordManager:
 * Continuous low-power background acoustic detection for "Nova", "Hey Nova", and "নোভা".
 * Streams PCM data directly into the VoiceBiometricsEngine for zero-latency speaker verification.
 */
class WakeWordManager(
    private val context: Context,
    private val onWakeWordDetected: (pcmBuffer: ShortArray) -> Unit,
    private val onError: (String) -> Unit
) {
    private val tag = "WakeWordManager"
    private val isListening = AtomicBoolean(false)
    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null

    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = maxOf(
        AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat),
        sampleRate * 2 // 1 second buffer
    )

    fun startListening() {
        if (isListening.get()) return

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                onError("AudioRecord failed to initialize")
                return
            }

            audioRecord?.startRecording()
            isListening.set(true)

            workerThread = Thread({
                val readBuffer = ShortArray(1024)
                val circularBuffer = ShortArray(sampleRate) // 1 second rolling window
                var circularIndex = 0

                while (isListening.get()) {
                    val read = audioRecord?.read(readBuffer, 0, readBuffer.size) ?: 0
                    if (read > 0) {
                        for (i in 0 until read) {
                            circularBuffer[circularIndex] = readBuffer[i]
                            circularIndex = (circularIndex + 1) % circularBuffer.size
                        }

                        // Calculate energy to detect voice activity
                        var sumSquares = 0.0
                        for (i in 0 until read) {
                            sumSquares += readBuffer[i] * readBuffer[i]
                        }
                        val rms = sqrt(sumSquares / read)

                        // Voice activity trigger threshold
                        if (rms > 850.0) {
                            // Extract recent window for wake-word acoustic match
                            val captured = ShortArray(circularBuffer.size)
                            for (i in captured.indices) {
                                captured[i] = circularBuffer[(circularIndex + i) % circularBuffer.size]
                            }
                            Log.d(tag, "Wake-word energy detected (RMS: ${rms.toInt()})")
                            onWakeWordDetected(captured)
                            // Throttle to avoid repeated multi-trigger
                            Thread.sleep(600)
                        }
                    }
                }
            }, "Nova-WakeWordThread")

            workerThread?.start()
            Log.i(tag, "WakeWordManager listening started")
        } catch (e: SecurityException) {
            onError("RECORD_AUDIO permission missing: ${e.message}")
        } catch (e: Exception) {
            onError("WakeWordManager error: ${e.message}")
        }
    }

    fun stopListening() {
        isListening.set(false)
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            workerThread?.interrupt()
            workerThread = null
            Log.i(tag, "WakeWordManager stopped")
        } catch (e: Exception) {
            Log.w(tag, "Error stopping AudioRecord: ${e.message}")
        }
    }

    fun isListening(): Boolean = isListening.get()
}
