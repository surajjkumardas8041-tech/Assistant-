package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "interactions")
data class InteractionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val userQuery: String,
    val assistantResponse: String,
    val actionType: String? = null,
    val language: String = "auto",
    val isHandsFree: Boolean = true,
    val isVoiceVerified: Boolean = true,
    val verificationScore: Float = 1.0f
)
