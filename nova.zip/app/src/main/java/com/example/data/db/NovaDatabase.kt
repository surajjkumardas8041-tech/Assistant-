package com.example.data.db

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "interaction_history")
data class InteractionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val queryText: String,
    val responseText: String,
    val actionType: String,
    val isOwnerVerified: Boolean,
    val isSuccess: Boolean
)

@Dao
interface InteractionDao {
    @Query("SELECT * FROM interaction_history ORDER BY timestamp DESC LIMIT 100")
    fun getAllInteractions(): Flow<List<InteractionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInteraction(item: InteractionEntity)

    @Query("DELETE FROM interaction_history")
    suspend fun clearHistory()
}

@Database(entities = [InteractionEntity::class], version = 1, exportSchema = false)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun interactionDao(): InteractionDao

    companion object {
        @Volatile
        private var INSTANCE: NovaDatabase? = null

        fun getInstance(context: Context): NovaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NovaDatabase::class.java,
                    "nova_assistant_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
