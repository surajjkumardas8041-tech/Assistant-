package com.example.data.model

enum class AssistantState(val displayName: String, val bengaliName: String) {
    READY("Nova Ready", "নোভা প্রস্তুত"),
    WAKE_DETECTED("Wake Word Detected", "ওয়েক ওয়ার্ড সনাক্ত"),
    VERIFYING_VOICE("Verifying Voice Identity", "কণ্ঠস্বর যাচাই চলছে..."),
    LISTENING("Listening...", "শুনছি..."),
    PROCESSING("Thinking...", "প্রসেসিং হচ্ছে..."),
    SPEAKING("Speaking...", "উত্তর দিচ্ছি..."),
    DENIED("Unauthorized Voice", "অননুমোদিত কণ্ঠস্বর"),
    PAUSED("Paused", "সাময়িক স্থগিত"),
    ERROR("Error", "সমস্যা হয়েছে")
}

data class VoiceCommandResult(
    val query: String,
    val responseText: String,
    val actionExecuted: String? = null,
    val success: Boolean = true,
    val isVerifiedOwner: Boolean = true
)
