package com.example.data.model

import androidx.annotation.Keep
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@Keep
enum class SecuritySensitivity(val threshold: Float, val displayName: String, val bengaliName: String) {
    STANDARD(0.72f, "Standard (Recommended)", "সাধারণ (সুপারিশকৃত)"),
    HIGH(0.80f, "High Security", "উচ্চ নিরাপত্তা"),
    STRICT(0.88f, "Strict Biometric", "কঠোর বায়োমেট্রিক")
}

@Keep
enum class VerificationStatus(val displayName: String, val bengaliName: String) {
    VERIFIED("Authorized Owner", "অনুমোদিত মালিক"),
    REJECTED_UNAUTHORIZED("Unauthorized Voice", "অননুমোদিত কণ্ঠ"),
    REJECTED_SPOOF_DETECTED("Potential Spoof/Replay Detected", "জাল কণ্ঠ সনাক্ত"),
    NO_ENROLLMENT("Voice Not Enrolled", "কণ্ঠস্বর সংরক্ষিত নেই"),
    ERROR("Verification Error", "যাচাই ত্রুটি")
}

@Keep
@JsonClass(generateAdapter = true)
data class VoiceProfile(
    @param:Json(name = "ownerName") val ownerName: String,
    @param:Json(name = "enrollmentTimestamp") val enrollmentTimestamp: Long,
    @param:Json(name = "sampleCount") val sampleCount: Int,
    @param:Json(name = "voiceprintVector") val voiceprintVector: List<Float>,
    @param:Json(name = "pitchCentroid") val pitchCentroid: Float,
    @param:Json(name = "energyVariance") val energyVariance: Float,
    @param:Json(name = "livenessSignature") val livenessSignature: Float,
    @param:Json(name = "fingerprintChecksum") val fingerprintChecksum: String
)

@Keep
data class VoiceVerificationResult(
    val status: VerificationStatus,
    val isOwner: Boolean,
    val confidence: Float,
    val similarityScore: Float,
    val livenessScore: Float,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
