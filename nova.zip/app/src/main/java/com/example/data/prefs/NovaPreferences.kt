package com.example.data.prefs

import android.content.Context
import android.content.SharedPreferences

class NovaPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nova_assistant_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_OWNER_NAME = "owner_name"
        private const val KEY_LANGUAGE_MODE = "language_mode"
        private const val KEY_SENSITIVITY = "voice_sensitivity"
        private const val KEY_VOICE_SECURITY_ENABLED = "voice_security_enabled"
        private const val KEY_SERVICE_AUTOSTART = "service_autostart"
        private const val KEY_VOICE_PITCH = "tts_pitch"
        private const val KEY_VOICE_SPEED = "tts_speed"
        private const val KEY_OWNER_VOICE_TEMPLATE = "owner_voice_template"
        private const val KEY_ENROLLMENT_COUNT = "enrollment_sample_count"
    }

    var ownerName: String
        get() = prefs.getString(KEY_OWNER_NAME, "তাপস স্যার") ?: "তাপস স্যার"
        set(value) = prefs.edit().putString(KEY_OWNER_NAME, value).apply()

    var languageMode: String
        get() = prefs.getString(KEY_LANGUAGE_MODE, "auto") ?: "auto"
        set(value) = prefs.edit().putString(KEY_LANGUAGE_MODE, value).apply()

    var voiceSensitivity: Float
        get() = prefs.getFloat(KEY_SENSITIVITY, 0.72f)
        set(value) = prefs.edit().putFloat(KEY_SENSITIVITY, value).apply()

    var isVoiceSecurityEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOICE_SECURITY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_VOICE_SECURITY_ENABLED, value).apply()

    var isServiceAutoStartEnabled: Boolean
        get() = prefs.getBoolean(KEY_SERVICE_AUTOSTART, true)
        set(value) = prefs.edit().putBoolean(KEY_SERVICE_AUTOSTART, value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat(KEY_VOICE_PITCH, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_PITCH, value).apply()

    var ttsSpeed: Float
        get() = prefs.getFloat(KEY_VOICE_SPEED, 1.05f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_SPEED, value).apply()

    var ownerVoiceTemplate: String?
        get() = prefs.getString(KEY_OWNER_VOICE_TEMPLATE, null)
        set(value) = prefs.edit().putString(KEY_OWNER_VOICE_TEMPLATE, value).apply()

    var enrollmentSampleCount: Int
        get() = prefs.getInt(KEY_ENROLLMENT_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_ENROLLMENT_COUNT, value).apply()

    fun isOwnerEnrolled(): Boolean = !ownerVoiceTemplate.isNullOrEmpty()
}
