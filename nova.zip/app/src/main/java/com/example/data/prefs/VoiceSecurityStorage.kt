package com.example.data.prefs

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.SecuritySensitivity
import com.example.data.model.VoiceProfile
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class VoiceSecurityStorage(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("nova_voice_security_prefs", Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
    private val profileAdapter = moshi.adapter(VoiceProfile::class.java)

    companion object {
        private const val KEY_PROFILE_JSON = "voice_profile_json"
        private const val KEY_SECURITY_ENABLED = "voice_security_enabled"
        private const val KEY_SENSITIVITY = "voice_security_sensitivity"
        private const val KEY_ANTI_SPOOFING = "anti_spoofing_enabled"
        private const val KEY_FAIL_CLOSED = "fail_closed_enabled"
        private const val KEY_ENROLLMENT_DATE = "enrollment_date"
    }

    var isVoiceSecurityEnabled: Boolean
        get() = prefs.getBoolean(KEY_SECURITY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SECURITY_ENABLED, value).apply()

    var sensitivity: SecuritySensitivity
        get() {
            val name = prefs.getString(KEY_SENSITIVITY, SecuritySensitivity.STANDARD.name) ?: SecuritySensitivity.STANDARD.name
            return try {
                SecuritySensitivity.valueOf(name)
            } catch (e: Exception) {
                SecuritySensitivity.STANDARD
            }
        }
        set(value) = prefs.edit().putString(KEY_SENSITIVITY, value.name).apply()

    var isAntiSpoofingEnabled: Boolean
        get() = prefs.getBoolean(KEY_ANTI_SPOOFING, true)
        set(value) = prefs.edit().putBoolean(KEY_ANTI_SPOOFING, value).apply()

    var isFailClosedEnabled: Boolean
        get() = prefs.getBoolean(KEY_FAIL_CLOSED, true)
        set(value) = prefs.edit().putBoolean(KEY_FAIL_CLOSED, value).apply()

    fun isEnrolled(): Boolean {
        return getEnrolledProfile() != null
    }

    fun getEnrolledProfile(): VoiceProfile? {
        val json = prefs.getString(KEY_PROFILE_JSON, null) ?: return null
        return try {
            profileAdapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    fun saveVoiceProfile(profile: VoiceProfile) {
        val json = profileAdapter.toJson(profile)
        prefs.edit()
            .putString(KEY_PROFILE_JSON, json)
            .putLong(KEY_ENROLLMENT_DATE, profile.enrollmentTimestamp)
            .putBoolean(KEY_SECURITY_ENABLED, true)
            .apply()
    }

    fun clearVoiceProfile() {
        prefs.edit()
            .remove(KEY_PROFILE_JSON)
            .remove(KEY_ENROLLMENT_DATE)
            .apply()
    }
}
