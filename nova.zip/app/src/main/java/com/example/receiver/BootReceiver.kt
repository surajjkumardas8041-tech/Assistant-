package com.example.receiver

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.prefs.NovaPreferences
import com.example.service.NovaVoiceService

class BootReceiver : BroadcastReceiver() {
    private val tag = "BootReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(tag, "Received broadcast action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "android.intent.action.LOCKED_BOOT_COMPLETED"
        ) {
            val prefs = NovaPreferences(context)
            if (prefs.isServiceEnabled && prefs.isHandsFreeEnabled) {
                val hasRecordAudio = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasRecordAudio) {
                    Log.i(tag, "Boot completed: Initializing NovaVoiceService in background")
                    NovaVoiceService.startService(context)
                } else {
                    Log.w(tag, "Audio permission not yet granted; skipping automatic background start")
                }
            }
        }
    }
}
