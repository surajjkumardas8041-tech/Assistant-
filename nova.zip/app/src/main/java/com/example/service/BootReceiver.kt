package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.prefs.NovaPreferences

class BootReceiver : BroadcastReceiver() {
    private val tag = "BootReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.i(tag, "Boot broadcast received: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val preferences = NovaPreferences(context)
            if (preferences.isServiceAutoStartEnabled) {
                Log.i(tag, "Auto-starting NovaVoiceService on device startup...")
                val serviceIntent = Intent(context, NovaVoiceService::class.java).apply {
                    this.action = NovaVoiceService.ACTION_START_SERVICE
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Failed to start Nova service on boot: ${e.message}", e)
                }
            }
        }
    }
}
