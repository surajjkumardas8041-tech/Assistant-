package com.example.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.NovaApplication
import com.example.core.action.IntentActionHandler
import com.example.core.ai.NovaAIManager
import com.example.core.audio.*
import com.example.data.db.InteractionEntity
import com.example.data.db.NovaDatabase
import com.example.data.prefs.NovaPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

enum class NovaServiceState {
    READY,
    LISTENING,
    VERIFYING,
    PROCESSING,
    SPEAKING,
    CALL_ACTIVE,
    ERROR,
    STOPPED
}

class NovaVoiceService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 1001
        const val ACTION_START_SERVICE = "com.example.action.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
        const val ACTION_TRIGGER_MIC_FALLBACK = "com.example.action.TRIGGER_MIC"

        private val _assistantState = MutableStateFlow(NovaServiceState.READY)
        val assistantState: StateFlow<NovaServiceState> = _assistantState.asStateFlow()

        private val _lastSpokenTranscript = MutableStateFlow("")
        val lastSpokenTranscript: StateFlow<String> = _lastSpokenTranscript.asStateFlow()

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()
    }

    private val tag = "NovaVoiceService"
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private lateinit var preferences: NovaPreferences
    private lateinit var securityManager: VoiceSecurityManager
    private lateinit var actionHandler: IntentActionHandler
    private lateinit var aiManager: NovaAIManager
    private lateinit var callStateManager: CallStateManager
    private lateinit var database: NovaDatabase

    private var wakeWordManager: WakeWordManager? = null
    private var speechRecognizerManager: SpeechRecognizerManager? = null
    private var ttsManager: TextToSpeechManager? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private val isManuallyPaused = AtomicBoolean(false)
    private var screenReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(tag, "NovaVoiceService onCreate")

        preferences = NovaPreferences(this)
        securityManager = VoiceSecurityManager(this, preferences)
        actionHandler = IntentActionHandler(this, preferences)
        aiManager = NovaAIManager(this, preferences)
        database = NovaDatabase.getInstance(this)

        acquireWakeLock()
        initAudioEngines()
        initCallAndFocusManager()
        registerScreenStateReceiver()

        actionHandler.onCallInitiatedWithSpeaker = { target ->
            callStateManager.prepareOutgoingCallSpeaker(target)
        }

        _isServiceRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_SERVICE
        Log.i(tag, "onStartCommand action: $action")

        when (action) {
            ACTION_START_SERVICE -> {
                startForeground(NOTIFICATION_ID, buildForegroundNotification("Nova is ready & listening"))
                startWakeWordDetection()
            }
            ACTION_STOP_SERVICE -> {
                stopSelf()
            }
            ACTION_TRIGGER_MIC_FALLBACK -> {
                triggerManualSpeechRecognition()
            }
        }

        return START_STICKY
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Nova::VoiceServiceWakeLock"
            ).apply {
                acquire(24 * 60 * 60 * 1000L) // 24 hours
            }
            Log.i(tag, "Partial wake lock acquired for continuous service")
        } catch (e: Exception) {
            Log.w(tag, "Failed to acquire wake lock: ${e.message}")
        }
    }

    private fun initAudioEngines() {
        ttsManager = TextToSpeechManager(
            context = this,
            onInitSuccess = { Log.i(tag, "TTS ready in background service") },
            onSpeechDone = {
                Log.i(tag, "TTS playback finished -> Re-arming to READY")
                callStateManager.releaseNovaAudioFocus()
                reArmToReady()
            }
        )

        speechRecognizerManager = SpeechRecognizerManager(
            context = this,
            onResult = { text -> handleSpokenCommand(text) },
            onPartialResult = { partial -> _lastSpokenTranscript.value = partial },
            onError = { code, msg ->
                Log.w(tag, "Speech recognition error: $msg")
                reArmToReady()
            }
        )
    }

    private fun initCallAndFocusManager() {
        callStateManager = CallStateManager(
            context = this,
            onCallStarted = {
                Log.i(tag, "Call active -> Silencing wake word & microphone")
                _assistantState.value = NovaServiceState.CALL_ACTIVE
                wakeWordManager?.stopListening()
                speechRecognizerManager?.stopListening()
                ttsManager?.stop()
                updateNotification("Call in progress (Mic Paused)")
            },
            onCallEnded = {
                Log.i(tag, "Call finished -> Automatically restoring Nova to READY")
                updateNotification("Nova is ready & listening")
                reArmToReady()
            },
            onAudioFocusLost = { isTransient ->
                if (isTransient) {
                    ttsManager?.stop()
                } else {
                    wakeWordManager?.stopListening()
                }
            },
            onAudioFocusGained = {
                if (!isManuallyPaused.get() && !callStateManager.isPhoneCallOngoing()) {
                    reArmToReady()
                }
            },
            onSpeakerphoneActivated = { target ->
                Log.i(tag, "Call connected to $target: Speakerphone activated")
                val isBengali = preferences.languageMode == "bn" || preferences.languageMode == "auto"
                val notice = if (isBengali) "জি ${preferences.ownerName}, কলটি স্পিকারে দেওয়া হয়েছে।"
                else "Yes ${preferences.ownerName}, call is on loudspeaker."
                updateNotification(notice)
            }
        )
        callStateManager.startListening()
    }

    private fun registerScreenStateReceiver() {
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF,
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> {
                        if (!callStateManager.isPhoneCallOngoing() && !isManuallyPaused.get()) {
                            if (wakeWordManager?.isListening() != true) {
                                startWakeWordDetection()
                            }
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)
    }

    private fun startWakeWordDetection() {
        if (callStateManager.isPhoneCallOngoing()) {
            _assistantState.value = NovaServiceState.CALL_ACTIVE
            return
        }

        wakeWordManager?.stopListening()
        wakeWordManager = WakeWordManager(
            context = this,
            onWakeWordDetected = { pcmAudio ->
                handleWakeWordTrigger(pcmAudio)
            },
            onError = { err ->
                Log.w(tag, "WakeWord error: $err")
            }
        )
        wakeWordManager?.startListening()
        _assistantState.value = NovaServiceState.READY
    }

    private fun handleWakeWordTrigger(pcmAudio: ShortArray) {
        serviceScope.launch {
            wakeWordManager?.stopListening()
            _assistantState.value = NovaServiceState.VERIFYING
            SoundEffects.playWakeBeep()

            // 1. Owner Voice Verification
            val verification = securityManager.verifyVoice(pcmAudio)
            if (!verification.isVerified) {
                Log.w(tag, "Unauthorized voice rejected: ${verification.reason}")
                _assistantState.value = NovaServiceState.ERROR
                SoundEffects.playSecurityRejectTone()
                delay(800)
                reArmToReady()
                return@launch
            }

            Log.i(tag, "Owner verified successfully (${verification.confidence})")
            _assistantState.value = NovaServiceState.LISTENING
            SoundEffects.playAcknowledgeTone()
            callStateManager.requestNovaAudioFocus()

            // 2. Start Speech Recognition
            speechRecognizerManager?.startListening(preferences.languageMode)
        }
    }

    fun triggerManualSpeechRecognition() {
        serviceScope.launch {
            wakeWordManager?.stopListening()
            _assistantState.value = NovaServiceState.LISTENING
            SoundEffects.playAcknowledgeTone()
            callStateManager.requestNovaAudioFocus()
            speechRecognizerManager?.startListening(preferences.languageMode)
        }
    }

    private fun handleSpokenCommand(commandText: String) {
        if (commandText.isBlank()) {
            reArmToReady()
            return
        }

        _lastSpokenTranscript.value = commandText
        _assistantState.value = NovaServiceState.PROCESSING

        serviceScope.launch {
            // 1. Check Offline / Device Intent Handlers
            val actionResult = actionHandler.processCommand(commandText)
            val responseText: String
            val actionType: String
            val isSuccess: Boolean

            if (actionResult != null) {
                responseText = actionResult.responseText
                actionType = actionResult.actionExecuted
                isSuccess = actionResult.success
            } else {
                // 2. Conversational AI fallback
                responseText = aiManager.generateResponse(commandText)
                actionType = "AI_CHAT"
                isSuccess = true
            }

            // Save to DB
            try {
                database.interactionDao().insertInteraction(
                    InteractionEntity(
                        queryText = commandText,
                        responseText = responseText,
                        actionType = actionType,
                        isOwnerVerified = true,
                        isSuccess = isSuccess
                    )
                )
            } catch (e: Exception) {
                Log.w(tag, "Failed to save interaction: ${e.message}")
            }

            // 3. Speak Response
            _assistantState.value = NovaServiceState.SPEAKING
            ttsManager?.speak(
                text = responseText,
                pitch = preferences.ttsPitch,
                speed = preferences.ttsSpeed
            )
        }
    }

    private fun reArmToReady() {
        if (callStateManager.isPhoneCallOngoing()) {
            _assistantState.value = NovaServiceState.CALL_ACTIVE
            return
        }

        _assistantState.value = NovaServiceState.READY
        startWakeWordDetection()
    }

    private fun buildForegroundNotification(status: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NovaApplication.CHANNEL_ID)
            .setContentTitle("Nova Live Assistant")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildForegroundNotification(status))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        Log.i(tag, "NovaVoiceService onDestroy")
        _isServiceRunning.value = false
        _assistantState.value = NovaServiceState.STOPPED

        serviceScope.cancel()
        wakeWordManager?.stopListening()
        speechRecognizerManager?.destroy()
        ttsManager?.shutdown()
        callStateManager.stopListening()

        try {
            screenReceiver?.let { unregisterReceiver(it) }
        } catch (_: Exception) {}

        if (wakeLock?.isHeld == true) {
            try {
                wakeLock?.release()
            } catch (_: Exception) {}
        }
    }
}
