package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.NovaServiceState
import com.example.ui.components.NovaOrb
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaHomeScreen(
    viewModel: NovaViewModel,
    hasPermissions: Boolean,
    onRequestPermissions: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val serviceState by viewModel.serviceState.collectAsState()
    val isServiceRunning by viewModel.isServiceRunning.collectAsState()
    val lastTranscript by viewModel.lastTranscript.collectAsState()
    val historyList by viewModel.history.collectAsState()
    val ownerName by viewModel.ownerNameState.collectAsState()
    val isEnrolled by viewModel.isEnrolled.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isServiceRunning) NovaGreen else NovaRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "NOVA LIVE",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { if (isServiceRunning) viewModel.stopService() else viewModel.startService() },
                        modifier = Modifier.testTag("service_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isServiceRunning) Icons.Default.PowerSettingsNew else Icons.Default.PlayArrow,
                            contentDescription = "Toggle Service",
                            tint = if (isServiceRunning) NovaGreen else TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NovaDarkBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = NovaSurfaceDark,
                contentColor = TextPrimary
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Live Assistant") },
                    label = { Text("Assistant") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NovaCyan,
                        indicatorColor = NovaSurfaceCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NovaCyan,
                        indicatorColor = NovaSurfaceCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Voice Security") },
                    label = { Text("Security") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NovaCyan,
                        indicatorColor = NovaSurfaceCard
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NovaCyan,
                        indicatorColor = NovaSurfaceCard
                    )
                )
            }
        },
        containerColor = NovaDarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> AssistantTab(
                    state = serviceState,
                    isServiceRunning = isServiceRunning,
                    lastTranscript = lastTranscript,
                    ownerName = ownerName,
                    hasPermissions = hasPermissions,
                    onRequestPermissions = onRequestPermissions,
                    onMicFallback = { viewModel.triggerMicFallback() }
                )
                1 -> HistoryTab(
                    history = historyList,
                    onClearHistory = { viewModel.clearHistory() }
                )
                2 -> SecurityTab(
                    viewModel = viewModel,
                    isEnrolled = isEnrolled
                )
                3 -> SettingsTab(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AssistantTab(
    state: NovaServiceState,
    isServiceRunning: Boolean,
    lastTranscript: String,
    ownerName: String,
    hasPermissions: Boolean,
    onRequestPermissions: () -> Unit,
    onMicFallback: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Status header
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Owner: $ownerName",
                style = MaterialTheme.typography.labelMedium,
                color = NovaCyan
            )
            Spacer(modifier = Modifier.height(4.dp))
            val statusText = when (state) {
                NovaServiceState.READY -> "Ready for \"Nova\" or \"নোভা\""
                NovaServiceState.LISTENING -> "Listening to command…"
                NovaServiceState.VERIFYING -> "Verifying Owner Voice…"
                NovaServiceState.PROCESSING -> "Executing action…"
                NovaServiceState.SPEAKING -> "Speaking response…"
                NovaServiceState.CALL_ACTIVE -> "Call Active (Mic Paused)"
                NovaServiceState.ERROR -> "Voice Mismatch / Error"
                NovaServiceState.STOPPED -> "Service Stopped"
            }
            Text(
                text = statusText,
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Animated Central Orb
        Box(
            modifier = Modifier.padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            NovaOrb(state = state, size = 200.dp)
        }

        // Live transcript / Command suggestions
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(NovaSurfaceDark)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (lastTranscript.isNotEmpty()) {
                Text(
                    text = "Transcript:",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = "\"$lastTranscript\"",
                    style = MaterialTheme.typography.bodyLarge,
                    color = NovaCyan,
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = "Try saying:",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = "“Nova, মাকে ফোন করো”\n“Nova, YouTube খোলো”\n“Nova, ব্যাটারি কত আছে?”",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Fallback Mic Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!hasPermissions) {
                Button(
                    onClick = onRequestPermissions,
                    colors = ButtonDefaults.buttonColors(containerColor = NovaAmber),
                    modifier = Modifier.testTag("request_permission_button")
                ) {
                    Text("Grant Required Permissions", color = NovaDarkBackground)
                }
            } else {
                IconButton(
                    onClick = onMicFallback,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(NovaCyanGlow)
                        .testTag("manual_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Manual Mic Fallback",
                        tint = NovaCyan,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryTab(
    history: List<com.example.data.db.InteractionEntity>,
    onClearHistory: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Interaction History",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            if (history.isNotEmpty()) {
                TextButton(onClick = onClearHistory) {
                    Text("Clear", color = NovaRed)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (history.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No voice interactions yet", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NovaSurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.actionType,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NovaCyan
                                )
                                val dateStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(item.timestamp))
                                Text(
                                    text = dateStr,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“${item.queryText}”",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.responseText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityTab(
    viewModel: NovaViewModel,
    isEnrolled: Boolean
) {
    val sensitivity = viewModel.preferences.voiceSensitivity
    val isSecurityEnabled = viewModel.preferences.isVoiceSecurityEnabled
    val sampleCount by viewModel.enrollmentCount.collectAsState()

    var sensitivityState by remember { mutableFloatStateOf(sensitivity) }
    var securityToggleState by remember { mutableStateOf(isSecurityEnabled) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Biometric Voice Security",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            Text(
                text = "On-device acoustic verification protects calls, apps, and personal device actions.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NovaSurfaceDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Voice Security Shield", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = securityToggleState,
                            onCheckedChange = {
                                securityToggleState = it
                                viewModel.toggleVoiceSecurity(it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NovaCyan,
                                checkedTrackColor = NovaCyanGlow
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEnrolled) "Status: Owner voice profile enrolled ($sampleCount samples)"
                        else "Status: Awaiting owner voice enrollment",
                        color = if (isEnrolled) NovaGreen else NovaAmber,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.resetVoiceEnrollment() },
                        colors = ButtonDefaults.buttonColors(containerColor = NovaSurfaceCard),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Re-enroll / Clear Voice Profile", color = NovaCyan)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NovaSurfaceDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Verification Sensitivity: ${(sensitivityState * 100).toInt()}%",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Slider(
                        value = sensitivityState,
                        onValueChange = {
                            sensitivityState = it
                            viewModel.setSensitivity(it)
                        },
                        valueRange = 0.5f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = NovaCyan,
                            activeTrackColor = NovaCyan
                        )
                    )
                    Text(
                        text = "Higher values reject more unauthorized speakers.",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsTab(viewModel: NovaViewModel) {
    var ownerNameText by remember { mutableStateOf(viewModel.preferences.ownerName) }
    var selectedLang by remember { mutableStateOf(viewModel.preferences.languageMode) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Preferences",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NovaSurfaceDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Owner Preferred Name", color = TextPrimary, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ownerNameText,
                        onValueChange = {
                            ownerNameText = it
                            viewModel.updateOwnerName(it)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaCyan,
                            unfocusedBorderColor = NovaSurfaceCard,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NovaSurfaceDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Speech Language Mode", color = TextPrimary, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    val options = listOf("auto" to "Bilingual (Auto Bengali & English)", "bn" to "Bengali Only", "en" to "English Only")
                    options.forEach { (mode, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedLang = mode
                                    viewModel.setLanguageMode(mode)
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedLang == mode,
                                onClick = {
                                    selectedLang = mode
                                    viewModel.setLanguageMode(mode)
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = NovaCyan)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(label, color = TextPrimary)
                        }
                    }
                }
            }
        }
    }
}
