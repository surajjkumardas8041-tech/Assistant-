package com.example.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.audio.VoiceSecurityManager
import com.example.data.db.InteractionEntity
import com.example.data.db.NovaDatabase
import com.example.data.prefs.NovaPreferences
import com.example.service.NovaServiceState
import com.example.service.NovaVoiceService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NovaViewModel(application: Application) : AndroidViewModel(application) {
    val preferences = NovaPreferences(application)
    private val securityManager = VoiceSecurityManager(application, preferences)
    private val database = NovaDatabase.getInstance(application)

    val serviceState: StateFlow<NovaServiceState> = NovaVoiceService.assistantState
    val isServiceRunning: StateFlow<Boolean> = NovaVoiceService.isServiceRunning
    val lastTranscript: StateFlow<String> = NovaVoiceService.lastSpokenTranscript

    val history: StateFlow<List<InteractionEntity>> = database.interactionDao()
        .getAllInteractions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _ownerNameState = MutableStateFlow(preferences.ownerName)
    val ownerNameState: StateFlow<String> = _ownerNameState.asStateFlow()

    private val _isEnrolled = MutableStateFlow(preferences.isOwnerEnrolled())
    val isEnrolled: StateFlow<Boolean> = _isEnrolled.asStateFlow()

    private val _enrollmentCount = MutableStateFlow(preferences.enrollmentSampleCount)
    val enrollmentCount: StateFlow<Int> = _enrollmentCount.asStateFlow()

    fun updateOwnerName(name: String) {
        preferences.ownerName = name
        _ownerNameState.value = name
    }

    fun setLanguageMode(mode: String) {
        preferences.languageMode = mode
    }

    fun setSensitivity(value: Float) {
        preferences.voiceSensitivity = value
    }

    fun toggleVoiceSecurity(enabled: Boolean) {
        preferences.isVoiceSecurityEnabled = enabled
    }

    fun resetVoiceEnrollment() {
        securityManager.resetEnrollment()
        _isEnrolled.value = false
        _enrollmentCount.value = 0
    }

    fun startService() {
        val intent = Intent(getApplication(), NovaVoiceService::class.java).apply {
            action = NovaVoiceService.ACTION_START_SERVICE
        }
        val context = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopService() {
        val intent = Intent(getApplication(), NovaVoiceService::class.java).apply {
            action = NovaVoiceService.ACTION_STOP_SERVICE
        }
        getApplication<Application>().stopService(intent)
    }

    fun triggerMicFallback() {
        val intent = Intent(getApplication(), NovaVoiceService::class.java).apply {
            action = NovaVoiceService.ACTION_TRIGGER_MIC_FALLBACK
        }
        val context = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            database.interactionDao().clearHistory()
        }
    }
}
