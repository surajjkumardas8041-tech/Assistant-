package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NovaAmber
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HandsFreeWorkflowCard(
    currentState: AssistantState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("hands_free_workflow_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚡ System-Wide Auto Voice Engine",
                color = CyberCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "All Apps & Background",
                color = NeonGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            WorkflowStepItem(
                stepNumber = "1",
                title = "READY",
                subtitle = "Say \"Nova\"",
                isActive = currentState == AssistantState.READY,
                activeColor = NeonGreen
            )

            WorkflowArrow()

            WorkflowStepItem(
                stepNumber = "2",
                title = "VERIFY",
                subtitle = "Owner Check",
                isActive = currentState == AssistantState.WAKE_DETECTED || currentState == AssistantState.VERIFYING_VOICE,
                activeColor = CyberCyan
            )

            WorkflowArrow()

            WorkflowStepItem(
                stepNumber = "3",
                title = "EXECUTE",
                subtitle = "AI Action",
                isActive = currentState == AssistantState.LISTENING || currentState == AssistantState.PROCESSING || currentState == AssistantState.SPEAKING,
                activeColor = NovaAmber
            )

            WorkflowArrow()

            WorkflowStepItem(
                stepNumber = "4",
                title = "RE-ARM",
                subtitle = "Auto Ready",
                isActive = currentState == AssistantState.READY,
                activeColor = NeonGreen
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F172A))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📱 YouTube • WhatsApp • Chrome • Calls auto-pause & auto-recover to READY",
                color = TextMuted,
                fontSize = 10.sp,
                lineHeight = 13.sp
            )
        }
    }
}

@Composable
private fun WorkflowStepItem(
    stepNumber: String,
    title: String,
    subtitle: String,
    isActive: Boolean,
    activeColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(68.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (isActive) activeColor else Color(0xFF1E293B)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                color = if (isActive) Color.Black else TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = if (isActive) activeColor else TextPrimary,
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
        )
        Text(
            text = subtitle,
            color = TextMuted,
            fontSize = 9.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun WorkflowArrow() {
    Text(
        text = "→",
        color = TextMuted,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
    )
}
