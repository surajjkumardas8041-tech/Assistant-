package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.service.NovaServiceState
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun NovaOrb(
    state: NovaServiceState,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    NovaServiceState.LISTENING -> 800
                    NovaServiceState.VERIFYING -> 400
                    NovaServiceState.PROCESSING -> 600
                    NovaServiceState.SPEAKING -> 700
                    else -> 1800
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_angle"
    )

    val primaryColor = when (state) {
        NovaServiceState.READY -> NovaCyan
        NovaServiceState.LISTENING -> NovaCyan
        NovaServiceState.VERIFYING -> NovaAmber
        NovaServiceState.PROCESSING -> NovaPurple
        NovaServiceState.SPEAKING -> NovaGreen
        NovaServiceState.CALL_ACTIVE -> NovaAmber
        NovaServiceState.ERROR -> NovaRed
        NovaServiceState.STOPPED -> TextMuted
    }

    val secondaryColor = when (state) {
        NovaServiceState.READY -> NovaPurple
        NovaServiceState.LISTENING -> NovaCyan
        NovaServiceState.VERIFYING -> NovaAmber
        NovaServiceState.PROCESSING -> NovaCyan
        NovaServiceState.SPEAKING -> NovaCyan
        NovaServiceState.CALL_ACTIVE -> NovaAmber
        NovaServiceState.ERROR -> NovaRed
        NovaServiceState.STOPPED -> TextMuted
    }

    Canvas(modifier = modifier.size(size)) {
        val canvasWidth = this.size.width
        val canvasHeight = this.size.height
        val centerOffset = Offset(canvasWidth / 2f, canvasHeight / 2f)
        val baseRadius = min(canvasWidth, canvasHeight) / 3f

        // Outer ambient glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(primaryColor.copy(alpha = 0.35f), Color.Transparent),
                center = centerOffset,
                radius = baseRadius * pulseScale * 1.5f
            ),
            radius = baseRadius * pulseScale * 1.5f,
            center = centerOffset
        )

        // Orbital particles / rings
        val numPoints = 8
        for (i in 0 until numPoints) {
            val angleDeg = rotationAngle + (i * (360f / numPoints))
            val angleRad = Math.toRadians(angleDeg.toDouble())
            val orbitalDist = baseRadius * pulseScale * 1.15f
            val px = centerOffset.x + (orbitalDist * cos(angleRad)).toFloat()
            val py = centerOffset.y + (orbitalDist * sin(angleRad)).toFloat()

            drawCircle(
                color = secondaryColor.copy(alpha = 0.6f),
                radius = 4.dp.toPx(),
                center = Offset(px, py)
            )
        }

        // Concentric glowing ring
        drawCircle(
            color = primaryColor.copy(alpha = 0.7f),
            radius = baseRadius * pulseScale,
            center = centerOffset,
            style = Stroke(width = 3.dp.toPx())
        )

        // Inner solid core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(primaryColor, secondaryColor),
                center = centerOffset,
                radius = baseRadius * 0.7f
            ),
            radius = baseRadius * 0.7f * pulseScale,
            center = centerOffset
        )
    }
}
