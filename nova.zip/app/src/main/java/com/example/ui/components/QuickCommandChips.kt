package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

data class VoicePromptChip(val title: String, val category: String)

@Composable
fun QuickCommandChips(
    onChipClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val chips = listOf(
        VoicePromptChip("নোভা, YouTube চালাও", "App Launch"),
        VoicePromptChip("নোভা, তুমি কি প্রস্তুত?", "Status"),
        VoicePromptChip("নোভা, flashlight on করো", "Hardware"),
        VoicePromptChip("নোভা, তানিশাকে কল দাও", "Calling"),
        VoicePromptChip("নোভা, ডিভাইসের চার্জ কত?", "Device Info"),
        VoicePromptChip("নোভা, এখন সময় কত?", "Time"),
        VoicePromptChip("নোভা, Google Maps খোলো", "Navigation"),
        VoicePromptChip("নোভা, ছবি তোলো", "Camera")
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("quick_command_chips_section")
    ) {
        Text(
            text = "Try Saying (Bengali / English):",
            color = TextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            chips.forEach { chip ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceCard)
                        .clickable { onChipClick(chip.title.replace("নোভা,", "").trim()) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = chip.title,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
