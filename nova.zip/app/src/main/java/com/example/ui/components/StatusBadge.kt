package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantState
import com.example.ui.theme.AiPurple
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NovaAmber
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun StatusBadge(
    state: AssistantState,
    isMicrophoneActive: Boolean,
    modifier: Modifier = Modifier
) {
    val (statusColor, dotColor) = when (state) {
        AssistantState.READY -> Pair(NeonGreen, NeonGreen)
        AssistantState.WAKE_DETECTED -> Pair(NovaAmber, NovaAmber)
        AssistantState.VERIFYING_VOICE -> Pair(CyberCyan, CyberCyan)
        AssistantState.LISTENING -> Pair(NovaAmber, NovaAmber)
        AssistantState.PROCESSING -> Pair(AiPurple, AiPurple)
        AssistantState.SPEAKING -> Pair(CyberCyan, CyberCyan)
        AssistantState.DENIED -> Pair(Color(0xFFFF1744), Color(0xFFFF1744))
        AssistantState.PAUSED -> Pair(Color(0xFF94A3B8), Color(0xFF64748B))
        AssistantState.ERROR -> Pair(Color(0xFFEF4444), Color(0xFFEF4444))
    }

    val animatedBorderColor by animateColorAsState(targetValue = statusColor, label = "BorderColor")

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(32.dp))
            .background(SurfaceCard)
            .border(1.dp, animatedBorderColor.copy(alpha = 0.5f), RoundedCornerShape(32.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("status_badge")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = state.displayName,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = state.bengaliName,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
            if (isMicrophoneActive) {
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x33FF9100))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "MIC ON",
                        color = NovaAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
