package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.VoiceProfile
import com.example.ui.NovaViewModel
import kotlinx.coroutines.launch

@Composable
fun VoiceEnrollmentDialog(
    viewModel: NovaViewModel,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val currentOwnerName by viewModel.ownerName.collectAsState()
    val enrollmentRms by viewModel.enrollmentRms.collectAsState()

    var ownerNameInput by remember { mutableStateOf(currentOwnerName) }
    var currentStep by remember { mutableIntStateOf(0) }
    var isRecording by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }
    var enrolledProfile by remember { mutableStateOf<VoiceProfile?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val recordedSamples = remember { mutableStateListOf<ShortArray>() }

    val samplePrompts = listOf(
        Pair("নোভা, আমি তাপস স্যার", "Nova, I am Tapas Sir"),
        Pair("নোভা, আমার নির্দেশ শোনো", "Nova, listen to my voice commands"),
        Pair("নোভা, ভয়েস সিকিউরিটি চালু করো", "Nova, activate voice security")
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRecording) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isRecording) 600 else 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Dialog(
        onDismissRequest = {
            if (!isRecording && !isProcessing) onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF007A))
                    ),
                    shape = RoundedCornerShape(24.dp)
                ),
            color = Color(0xFF0D1117)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Voice Enrollment",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Owner Voice Enrollment",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "মালিকের কণ্ঠস্বর নিবন্ধন",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFF00E5FF)
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isRecording && !isProcessing,
                        modifier = Modifier.testTag("close_enrollment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (enrolledProfile != null) {
                    // Success View
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E676).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Voice Lock Activated!",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "আপনার কণ্ঠস্বর সফলভাবে সংরক্ষিত হয়েছে",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFF00E676)
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Authorized Owner: ${enrolledProfile?.ownerName}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Text(
                                    text = "Biometric Checksum: ${enrolledProfile?.fingerprintChecksum}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color(0xFF00E5FF)
                                    )
                                )
                                Text(
                                    text = "Samples Captured: ${enrolledProfile?.sampleCount} verified acoustic samples",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.Gray
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "🛡️ Nova will now only accept sensitive and assistant commands from your verified voice.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color(0xFFFFD54F)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("done_enrollment_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00E5FF),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                text = "Done / সম্পন্ন",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                } else {
                    // Wizard Steps
                    OutlinedTextField(
                        value = ownerNameInput,
                        onValueChange = { ownerNameInput = it },
                        label = { Text("Owner Name / আপনার নাম") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedLabelColor = Color(0xFF00E5FF),
                            unfocusedLabelColor = Color.Gray
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("owner_name_enrollment_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        enabled = !isRecording && !isProcessing
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Sample ${currentStep + 1} of 3",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "${recordedSamples.size}/3 Recorded",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (recordedSamples.size) / 3f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF00E5FF),
                        trackColor = Color(0xFF21262D)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Prompt Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Please say clearly into mic:",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "“${samplePrompts.getOrElse(currentStep) { samplePrompts[0] }.first}”",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color(0xFF00E5FF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    textAlign = TextAlign.Center
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "(${samplePrompts.getOrElse(currentStep) { samplePrompts[0] }.second})",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.LightGray,
                                    textAlign = TextAlign.Center
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Dynamic Mic Button & Meter
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(110.dp)
                    ) {
                        if (isRecording) {
                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF007A).copy(alpha = 0.25f))
                            )
                        }

                        IconButton(
                            onClick = {
                                if (!isRecording && !isProcessing) {
                                    scope.launch {
                                        errorMessage = null
                                        isRecording = true
                                        val sample = viewModel.recordVoiceSample(durationMs = 3000L)
                                        isRecording = false
                                        if (sample != null && sample.size > 8000) {
                                            recordedSamples.add(sample)
                                            if (currentStep < 2) {
                                                currentStep++
                                            } else {
                                                // All 3 samples recorded! Train profile
                                                isProcessing = true
                                                val profile = viewModel.saveEnrollment(
                                                    samples = recordedSamples.toList(),
                                                    ownerName = ownerNameInput
                                                )
                                                isProcessing = false
                                                if (profile) {
                                                    enrolledProfile = viewModel.voiceSecurityManager.storage.getEnrolledProfile()
                                                } else {
                                                    errorMessage = "Voice training failed. Please re-record in quiet space."
                                                }
                                            }
                                        } else {
                                            errorMessage = "Audio too quiet or short. Please speak louder."
                                        }
                                    }
                                }
                            },
                            enabled = !isRecording && !isProcessing,
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isRecording) Color(0xFFFF007A)
                                    else Color(0xFF00E5FF)
                                )
                                .testTag("record_sample_button")
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.Black,
                                    modifier = Modifier.size(32.dp),
                                    strokeWidth = 3.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Record Voice Sample",
                                    tint = Color.Black,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isRecording) "Recording... Speak prompt now"
                        else if (isProcessing) "Generating Biometric Voiceprint..."
                        else "Tap Mic to Record 3-Second Sample",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isRecording) Color(0xFFFF007A) else Color.Gray,
                            fontWeight = if (isRecording) FontWeight.Bold else FontWeight.Normal
                        )
                    )

                    if (isRecording) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { (enrollmentRms / 10f).coerceIn(0.1f, 1f) },
                            modifier = Modifier
                                .width(160.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color(0xFFFF007A),
                            trackColor = Color(0xFF21262D)
                        )
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFFFF5252),
                                textAlign = TextAlign.Center
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (recordedSamples.isNotEmpty() && !isRecording && !isProcessing) {
                        TextButton(
                            onClick = {
                                recordedSamples.clear()
                                currentStep = 0
                                errorMessage = null
                            }
                        ) {
                            Text("Reset & Start Over / পুনরায় শুরু করুন", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
