package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SecuritySensitivity
import com.example.data.model.VerificationStatus
import com.example.ui.NovaViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VoiceSecuritySettingsDialog(
    viewModel: NovaViewModel,
    onDismiss: () -> Unit,
    onOpenEnrollment: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val isEnrolled by viewModel.isVoiceEnrolled.collectAsState()
    val isSecurityEnabled by viewModel.isVoiceSecurityEnabled.collectAsState()
    val currentSensitivity by viewModel.securitySensitivity.collectAsState()
    val isAntiSpoofingEnabled by viewModel.isAntiSpoofingEnabled.collectAsState()
    val ownerName by viewModel.ownerName.collectAsState()
    val enrollmentRms by viewModel.enrollmentRms.collectAsState()
    val testResult by viewModel.testVerificationResult.collectAsState()

    var isTestingLive by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val enrolledProfile = remember(isEnrolled) {
        viewModel.voiceSecurityManager.storage.getEnrolledProfile()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF))
                    ),
                    shape = RoundedCornerShape(24.dp)
                ),
            color = Color(0xFF0D1117)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Voice Security",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Personal Voice Security",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "ব্যক্তিগত ভয়েস বায়োমেট্রিক্স সুরক্ষা",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFF00E5FF)
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_security_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Profile Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isEnrolled) Color(0xFF161B22) else Color(0xFF261818)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (isEnrolled && isSecurityEnabled) Color(0xFF00E676) else Color(0xFFFF5252))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isEnrolled && isSecurityEnabled) "OWNER VOICE LOCK: ACTIVE"
                                    else if (isEnrolled) "OWNER VOICE LOCK: PAUSED"
                                    else "NO VOICE ENROLLED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isEnrolled && isSecurityEnabled) Color(0xFF00E676) else Color(0xFFFF5252),
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }

                            if (isEnrolled) {
                                Text(
                                    text = enrolledProfile?.fingerprintChecksum ?: "NOVA-SEC",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF00E5FF),
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (isEnrolled && enrolledProfile != null) {
                            Text(
                                text = "Authorized Speaker: ${enrolledProfile.ownerName}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                                .format(Date(enrolledProfile.enrollmentTimestamp))
                            Text(
                                text = "Enrolled: $dateStr (${enrolledProfile.sampleCount} biometric samples)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            )
                        } else {
                            Text(
                                text = "No owner voice enrolled. Anyone can issue commands until you enroll your voice.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.LightGray
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    onDismiss()
                                    onOpenEnrollment()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("enroll_voice_now_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF00E5FF),
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Enroll Owner Voice Now / নিবন্ধন করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }

                if (isEnrolled) {
                    Spacer(modifier = Modifier.height(16.dp))

                    // Security Active Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Voice Identity Lock",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Text(
                                text = "কেবলমাত্র আপনার কণ্ঠে সহকারী সক্রিয় হবে",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray, fontSize = 11.sp)
                            )
                        }
                        Switch(
                            checked = isSecurityEnabled,
                            onCheckedChange = { viewModel.setVoiceSecurityEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = Color(0xFF00E5FF),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("toggle_voice_security_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Anti-Spoofing Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Anti-Spoofing & Replay Protection",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Text(
                                text = "রেকর্ডিং ও কৃত্রিম অডিও ফিল্টার করবে",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray, fontSize = 11.sp)
                            )
                        }
                        Switch(
                            checked = isAntiSpoofingEnabled,
                            onCheckedChange = { viewModel.setAntiSpoofingEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = Color(0xFF7C4DFF),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("toggle_anti_spoofing_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sensitivity Selector
                    Text(
                        text = "Biometric Sensitivity / সংবেদনশীলতা",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SecuritySensitivity.entries.forEach { sensitivity ->
                            val isSelected = currentSensitivity == sensitivity
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setSecuritySensitivity(sensitivity) },
                                label = {
                                    Text(
                                        text = sensitivity.name.lowercase().replaceFirstChar { it.uppercase() },
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF00E5FF),
                                    selectedLabelColor = Color.Black,
                                    containerColor = Color(0xFF161B22),
                                    labelColor = Color.LightGray
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Live Test Verification Section
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "🧪 Live Voice Verification Test",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = Color(0xFF00E5FF),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "Speak into mic to test if Nova recognizes your voice",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    if (!isTestingLive) {
                                        scope.launch {
                                            isTestingLive = true
                                            viewModel.runLiveVoiceVerificationTest(durationMs = 3000L)
                                            isTestingLive = false
                                        }
                                    }
                                },
                                enabled = !isTestingLive,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isTestingLive) Color(0xFFFF007A) else Color(0xFF7C4DFF),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().testTag("test_voice_verification_button")
                            ) {
                                if (isTestingLive) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Listening to test voice...", fontSize = 13.sp)
                                } else {
                                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Test My Voice Live (3s)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            if (isTestingLive) {
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { (enrollmentRms / 10f).coerceIn(0.1f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = Color(0xFFFF007A),
                                    trackColor = Color(0xFF21262D)
                                )
                            }

                            if (testResult != null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                val res = testResult!!
                                val isOwner = res.isOwner && res.status == VerificationStatus.VERIFIED

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (isOwner) Color(0xFF00E676).copy(alpha = 0.15f)
                                            else Color(0xFFFF5252).copy(alpha = 0.15f)
                                        )
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = if (isOwner) "✓ VERIFIED OWNER" else "✕ UNAUTHORIZED / REJECTED",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    color = if (isOwner) Color(0xFF00E676) else Color(0xFFFF5252),
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                            Text(
                                                text = "Match: ${(res.confidence * 100).toInt()}%",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Acoustic Similarity: ${(res.similarityScore * 100).toInt()}% | Liveness: ${(res.livenessScore * 100).toInt()}%",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Color.LightGray,
                                                fontSize = 10.sp
                                            )
                                        )
                                        Text(
                                            text = res.details,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Color.Gray,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Re-enroll & Clear Profile Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onOpenEnrollment()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("re_enroll_voice_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF00E5FF)
                            )
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Re-enroll", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("delete_voice_profile_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFFF5252)
                            )
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset Profile", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Reset Voice Profile?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This will delete your enrolled biometric voiceprint. Anyone will be able to control Nova until a new voice is enrolled.",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteVoiceProfile()
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text("Delete Profile", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF161B22)
        )
    }
}
