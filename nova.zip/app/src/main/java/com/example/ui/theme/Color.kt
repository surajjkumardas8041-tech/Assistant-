package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NovaDarkBackground = Color(0xFF070B12)
val NovaSurfaceDark = Color(0xFF0F172A)
val NovaSurfaceCard = Color(0xFF1E293B)

val NovaCyan = Color(0xFF00E5FF)
val NovaCyanGlow = Color(0x6600E5FF)
val NovaPurple = Color(0xFF7C4DFF)
val NovaPurpleGlow = Color(0x667C4DFF)
val NovaAmber = Color(0xFFFFB300)
val NovaRed = Color(0xFFFF5252)
val NovaGreen = Color(0xFF00E676)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
