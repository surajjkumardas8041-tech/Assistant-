package com.example

import android.content.Context
import android.telephony.TelephonyManager
import androidx.test.core.app.ApplicationProvider
import com.example.core.action.IntentActionHandler
import com.example.core.audio.CallStateManager
import com.example.core.audio.VoiceBiometricsEngine
import com.example.core.audio.VoiceSecurityManager
import com.example.data.prefs.NovaPreferences
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CallRecoveryAndSystemVoiceTest {

    private lateinit var context: Context
    private lateinit var preferences: NovaPreferences

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        preferences = NovaPreferences(context)
        preferences.ownerName = "তাপস স্যার"
        preferences.isVoiceSecurityEnabled = true
        preferences.voiceSensitivity = 0.70f
        preferences.ownerVoiceTemplate = null
        preferences.enrollmentSampleCount = 0
    }

    @Test
    fun `test intent action handler executes offline commands`() {
        val handler = IntentActionHandler(context, preferences)

        // 1. Time query
        val timeRes = handler.processCommand("কটা বাজে")
        assertNotNull(timeRes)
        assertEquals("GET_TIME", timeRes?.actionExecuted)
        assertTrue(timeRes!!.responseText.contains("তাপস স্যার"))

        // 2. Date query
        val dateRes = handler.processCommand("আজ কি বার")
        assertNotNull(dateRes)
        assertEquals("GET_DATE", dateRes?.actionExecuted)

        // 3. Battery query
        val battRes = handler.processCommand("ব্যাটারি চার্জ কত")
        assertNotNull(battRes)
        assertEquals("GET_BATTERY", battRes?.actionExecuted)

        // 4. Readiness query
        val readyRes = handler.processCommand("তুমি কি প্রস্তুত?")
        assertNotNull(readyRes)
        assertEquals("CHECK_READY", readyRes?.actionExecuted)
        assertTrue(readyRes!!.responseText.contains("সর্বদা প্রস্তুত"))
    }

    @Test
    fun `test owner voice verification versus unauthorized voice rejection`() {
        val securityManager = VoiceSecurityManager(context, preferences)

        // Synthetic acoustic PCM sample A (Owner)
        val ownerSample = ShortArray(1600) { i ->
            (kotlin.math.sin(2.0 * Math.PI * 150.0 * i / 16000.0) * 15000).toInt().toShort()
        }

        // Enroll owner voice
        val enrolled = securityManager.enrollSample(ownerSample)
        assertTrue("Owner enrollment should succeed", enrolled)
        assertTrue("Owner should be enrolled", securityManager.isOwnerEnrolled())

        // Test with same owner voice
        val ownerVerification = securityManager.verifyVoice(ownerSample)
        assertTrue("Owner voice should be verified", ownerVerification.isVerified)
        assertTrue("Confidence should exceed threshold", ownerVerification.confidence >= 0.70f)

        // Synthetic acoustic PCM sample B (Imposter with different pitch ~300Hz and different harmonics)
        val imposterSample = ShortArray(1600) { i ->
            (kotlin.math.sin(2.0 * Math.PI * 310.0 * i / 16000.0) * 15000 +
                    kotlin.math.sin(2.0 * Math.PI * 620.0 * i / 16000.0) * 8000).toInt().toShort()
        }

        // Test with imposter voice
        val imposterVerification = securityManager.verifyVoice(imposterSample)
        assertFalse("Imposter voice must be rejected", imposterVerification.isVerified)
    }

    @Test
    fun `test voice command to make phone call initiates call and automatically enables speakerphone on connect`() {
        var speakerphoneTarget: String? = null
        var callEndedTriggered = false

        val callStateManager = CallStateManager(
            context = context,
            onCallStarted = {},
            onCallEnded = { callEndedTriggered = true },
            onAudioFocusLost = {},
            onAudioFocusGained = {},
            onSpeakerphoneActivated = { target ->
                speakerphoneTarget = target
            }
        )

        val handler = IntentActionHandler(context, preferences)
        handler.onCallInitiatedWithSpeaker = { target ->
            callStateManager.prepareOutgoingCallSpeaker(target)
        }

        // 1. Voice Command: "Nova, 9876543210-এ ফোন করো।"
        val callResult = handler.processCommand("Nova, 9876543210-এ ফোন করো।")
        assertNotNull("Call command should be recognized", callResult)
        assertEquals("CALL_PHONE", callResult?.actionExecuted)
        assertTrue(callResult!!.success)

        // 2. Call Connects (OFFHOOK) -> Speakerphone must turn ON automatically
        callStateManager.handleCallStateTransition(TelephonyManager.CALL_STATE_OFFHOOK)
        ShadowLooper.idleMainLooper()

        assertEquals("9876543210", speakerphoneTarget)
        assertTrue("Speakerphone controller should report active or enabled", callStateManager.speakerphoneController.isSpeakerphoneOn())

        // 3. Call Ends (IDLE) -> Speakerphone must turn OFF and trigger auto recovery to READY
        callStateManager.handleCallStateTransition(TelephonyManager.CALL_STATE_IDLE)
        ShadowLooper.idleMainLooper()
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks()

        assertFalse("Speakerphone should be disabled when call ends", callStateManager.speakerphoneController.isSpeakerphoneOn())
        assertTrue("Call ended recovery should be triggered", callEndedTriggered)
        assertFalse("Call should no longer be active", callStateManager.isPhoneCallOngoing())

        // 4. Immediately execute next command: "Nova, YouTube খোলো।"
        val nextCommand = handler.processCommand("Nova, YouTube খোলো।")
        assertNotNull(nextCommand)
        assertEquals("OPEN_YOUTUBE", nextCommand?.actionExecuted)
        assertTrue(nextCommand!!.success)
    }

    @Test
    fun `test contact name call parsing for make call to mom in bengali`() {
        var initiatedTarget: String? = null
        val handler = IntentActionHandler(context, preferences)
        handler.onCallInitiatedWithSpeaker = { target ->
            initiatedTarget = target
        }

        val result = handler.processCommand("নোভা, মাকে ফোন করো।")
        assertNotNull(result)
        assertEquals("CALL_PHONE", result?.actionExecuted)
        assertEquals("মা", initiatedTarget)
    }

    @Test
    fun `test audio focus request`() {
        val callStateManager = CallStateManager(
            context = context,
            onCallStarted = {},
            onCallEnded = {},
            onAudioFocusLost = {},
            onAudioFocusGained = {}
        )

        val granted = callStateManager.requestNovaAudioFocus()
        assertTrue("Audio focus should be granted", granted)
        callStateManager.releaseNovaAudioFocus()
    }
}
